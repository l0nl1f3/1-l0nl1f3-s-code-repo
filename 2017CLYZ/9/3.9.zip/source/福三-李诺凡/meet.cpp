#include<iostream>
#include<stdio.h>
using namespace std;
int main ()
{
	freopen("meet.in","r",stdin);
	freopen("meet.out","w",stdout);
	while (1)
	puts("FA��Q");
}
