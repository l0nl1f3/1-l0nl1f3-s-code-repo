#include <iostream>
#include <cstdio>
#include <cassert>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <cmath>
#include <string>
#include <sstream>
#include <map>
#include <set>
#include <queue>
#include <stack>
#include <vector>
#include <bitset>
#include <algorithm>

#define pb push_back
#define ppb pop_back
#define mp make_pair
#define all(x) (x).begin(),(x).end()
#define sz(x) (int)(x).size()
#define ll long long
#define bit __builtin_popcountll
#define sqr(x) (x) * (x)
#define forit(it,S) for(__typeof((S).begin()) it = (S).begin(); it != (S).end(); it++)

using namespace std;

typedef pair<int, int> pii;

const double eps = 1e-9;
const double pi = acos(-1.0);

const int maxn = (int)1e5 + 10;

vector<pii> g[maxn];
int p[maxn][20];
int ma[maxn][20];
int in[maxn],out[maxn];
int T = 0;
int x[2][2],sh[2],lc[2];
ll len[maxn];
ll cur = 0;

void dfs(int v, int pr, int edge) {
	len[v] = cur;
	in[v] = T++;
	p[v][0] = pr;
	ma[v][0] = edge;
	for (int i = 1; i < 20; i++) {
		p[v][i] = p[p[v][i - 1]][i - 1];
		ma[v][i] = max(ma[v][i - 1],ma[p[v][i - 1]][i - 1]);
	}
	for (int i = 0; i < sz(g[v]); i++) {
		int to = g[v][i].first;
		int cst = g[v][i].second;
		if (to == pr) continue;
		cur += cst;
		dfs(to,v,cst);
		cur -= cst;
	}
	out[v] = T++;
}

bool upper(int a, int b) {
	return in[a] <= in[b] && out[b] <= out[a];
}

int lca(int a, int b) {
	if (upper(a,b)) return a;
	if (upper(b,a)) return b;
	for (int i = 19; i >= 0; i--) {
		if (!upper(p[a][i],b)) {
			a = p[a][i];
		}
	}
	return p[a][0];
}

bool check(int a, int b, int c, int d, int &u, int &v) {
	if (upper(b,d) && upper(d,a)) {
		u = d;
		v = c;
		for (int i = 19; i >= 0; i--) {
			if (!upper(p[v][i],a)) {
				v = p[v][i];
			}
		}
		if (!upper(v,a)) v = p[v][0];
		assert(upper(v,a));
		return true;
	}
	if (upper(d,b) && upper(b,c)) {
		u = b;
		v = a;
		for (int i = 19; i >= 0; i--) {
			if (!upper(p[v][i],c)) {
				v = p[v][i];
			}
		}
		if (!upper(v,c)) v = p[v][0];
		assert(upper(v,c));
		return true;
	}
	return false;
}

int main() {
	freopen("meet.in","r",stdin);
	freopen("meet.out","w",stdout);
	int n,q; scanf("%d%d",&n,&q);
	
	for (int i = 0; i < n - 1; i++) {
		int u,v,w; scanf("%d%d%d",&u,&v,&w);
		--u;
		--v;
		g[u].pb(mp(v,w));
		g[v].pb(mp(u,w));
	}
	
	dfs(0,0,0);
	
	while(q--) {
		for (int i = 0; i < 2; i++) {
			scanf("%d%d%d",&x[i][0],&x[i][1],&sh[i]);
			--x[i][0];
			--x[i][1];
			lc[i] = lca(x[i][0],x[i][1]);
		}
		bool good = false;
		for (int i = 0; i < 2; i++) {
			for (int j = 0; j < 2; j++) {
				int u,v;
				if (!check(x[0][i],lc[0],x[1][j],lc[1],u,v)) continue;
				//cout << i << " " << j << " " << x[0][i] << " " << lc[0] << " " << x[1][j] << " " << lc[1] << " " << u << " " << v << endl;
				ll fx,fy,sx,sy;
				if (i == 0) {
					fx = len[x[0][0]] - len[v];
					fy = len[x[0][0]] - len[u];
				} else {
					fx = len[x[0][0]] - len[lc[0]] + len[u] - len[lc[0]];
					fy = len[x[0][0]] - len[lc[0]] + len[v] - len[lc[0]];
				}
				if (j == 0) {
					sx = len[x[1][0]] - len[v];
					sy = len[x[1][0]] - len[u];
				} else {
					sx = len[x[1][0]] - len[lc[1]] + len[u] - len[lc[1]];
					sy = len[x[1][0]] - len[lc[1]] + len[v] - len[lc[1]];
				}
				fx += sh[0];
				fy += sh[0];
				sx += sh[1];
				sy += sh[1];
				if (fy <= sx || sy <= fx) continue;
				if (i ^ j) {
					assert(len[v] - len[u] - abs(fx - sx) >= 0);
					if ((len[v] - len[u] - abs(fx - sx)) % 2 == 1) {
						good = true;
					} else {
						ll dist = (len[v] - len[u] - abs(fx - sx)) / 2;
						if (fx < sx && i == 0) dist += abs(fx - sx);
						if (sx < fx && j == 0) dist += abs(fx - sx);
						for (int i = 19; i >= 0; i--) {
							int pr = p[v][i];
							if (len[v] - len[pr] <= dist) {
								dist -= len[v] - len[pr];
								v = pr;
							}
						}
						if (dist != 0) good = true;
					}
				} else {
					int maa = 0;
					for (int i = 19; i >= 0; i--) {
						if (upper(u,p[v][i])) {
							maa = max(maa,ma[v][i]);
							v = p[v][i];
						}
					}
					if (maa > abs(fx - sx)) good = true;
				}
			}
		}
		puts(good ? "YES" : "NO");
	}
	
	return 0;
}
