#include<bits/stdc++.h>
#define FT first
#define SC second
#define PB push_back
#define MP make_pair
#define REP(i, l, r) for(int i = (l); i <= (r); i++)
#define PER(i, r, l) for(int i = (r); i >= (l); i--)
#define FOR(i, n) for(int i = 0; i < (n); i++)
#define ROF(i, n) for(int i = (n) - 1; i >= 0; i--)
#define VEP(i, x) for(int i = 0; i < x.size(); i++)
#define DFOR(i, x) for(int i = hd[x]; i; i = e[i].nxt)
#define MEM(a, b) memset(a, b, sizeof(a))
#define rint read<int>()
#define rll read<LL>()

using namespace std;
typedef long long LL;
typedef long double LD;
typedef pair<int, int> PI;
const int inf = 0x7fffffff;
const int MOD = 1000000007;

template <typename tn>
inline tn read(){
	char ch; tn f = 1;
	while (!isdigit(ch = getchar())) if (ch == '-') f = -1;
	tn x = ch - '0';
	while (isdigit(ch = getchar())) x = x * 10 + ch - '0';
	return x * f;
}
template <typename tn> inline void cmax(tn &a, tn b){ if (a < b) a = b; }
template <typename tn> inline void cmin(tn &a, tn b){ if (a > b) a = b; }

int t = 0, pri[100], cnt[100];
int pw(int x, int k, int p){ int s = 1; for(; k; k >>= 1, x = (LL)x * x % p) if (k & 1) s = (LL)s * x % p; return s; }
int ins(int x, int d){ 
	REP(i, 1, t) while (!(x % pri[i])) cnt[i] += d, x /= pri[i]; 
	return x;
}
int main(){
	freopen("magic.in", "r", stdin);
	freopen("magic.out", "w", stdout);
	int n = rint, p = rint, x = p, y;
	int Ans = 0, S = 1, phi = 1;
	MEM(cnt, 0);
	for (int i = 2; i * i <= x; ++i)
		if (!(x % i)){
			pri[++t] = i, phi *= (i - 1), x /= i;
			while (!(x % i)) phi *= i, x /= i;
		}
	if (x > 1) phi *= (x - 1), pri[++t] = x;
	REP(i, 1, n){
		int tmp = S;
		REP(j, 1, t) tmp = (LL)tmp * pw(pri[j], cnt[j], p) % p;
		Ans = ((LL)tmp * rint + Ans) % p;
		if (i == n) break;
		S = (LL)S * ins(n - i, 1) % p * pw(ins(i, -1), phi - 1, p) % p;
	}
	cout << Ans << endl;
}
